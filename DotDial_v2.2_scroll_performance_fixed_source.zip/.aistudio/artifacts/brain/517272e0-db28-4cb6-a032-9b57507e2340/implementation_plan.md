# UI Haptic Vibration & Per-Contact Calling Card Studio

Deliver tactile haptic vibration across navigation tabs, Settings on/off switches, and dialpad keys backed by an On/Off toggle in Settings, alongside a strictly per-contact Calling Card selection flow where tapping Calling Card opens a contact menu before choosing an image for that specific person.

## User Review & Critical Decisions

> [!IMPORTANT]
> All product behavior and placement choices below reflect your confirmed preferences.

- **Confirmed Decision 1 — Haptic Vibration Scope & Feel**: Crisp haptic click tick enabled across bottom/rail navigation tabs, Settings switches/toggles (vibrating on both ON and OFF transitions), and dialpad number/backspace keys.
- **Confirmed Decision 2 — Vibration Toggle Location & Default**: Added as **UI Navigation & Toggle Vibration** (default **ON**) inside the **Display FPS, Sounds & Audio** card in Settings, right beside the existing UI Sounds switch, and included in Settings JSON backup/restore.
- **Confirmed Decision 3 — Strictly Per-Contact Calling Card Flow**: Tapping **Calling Card** inside Settings → Caller Screen Backdrop opens a **Contact Calling Card Picker** bottom sheet first; choosing a contact launches the photo picker to set a Calling Card image exclusively for that individual contact (automatically switching that contact's active backdrop mode to Calling Card while turning Video/Photo off).

---

## 1. Overview & Core Concept

- **What It Does**:
  - **Tactile UI Haptics**: Adds responsive haptic feedback whenever the user switches navigation tabs, toggles any Setting on or off, or dials digits/backspaces on the keypad, controlled by a single **UI Navigation & Toggle Vibration** switch.
  - **Per-Contact Calling Card Studio**: Replaces the single global Calling Card picker in Settings with a dedicated **Contact Picker → Photo Picker** workflow so Calling Cards belong to individual people rather than one image for everyone.
- **Target Audience / Persona**: Nothing OS / Phone (3a) Lite users who want crisp physical-feeling dialer feedback and personalized full-screen calling cards tailored to specific contacts.
- **Key Value**: Prevents one Calling Card image from unintentionally applying to all callers, while giving every navigation and settings action crisp tactile confirmation that can be muted anytime in Settings.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **UI Vibration On/Off Control**:
     - Open **Settings → Display FPS, Sounds & Audio**.
     - Toggle **UI Navigation & Toggle Vibration** (`ON` by default).
     - Turning the switch **ON** plays an immediate confirmation haptic pulse; turning it **OFF** disables UI haptics across navigation tabs, Settings toggles, and dialpad keys (without muting incoming call ring vibration glyphs).
  2. **Tactile Navigation & Settings Feedback**:
     - Tapping any bottom navigation tab or tablet rail destination triggers a crisp click haptic (alongside UI sound if enabled).
     - Tapping any Settings `Switch` (including theme toggles, AI toggles, recording toggles, display switches, and contact spam-block switches) triggers a crisp haptic tick on both ON and OFF transitions.
     - Pressing any T9 dialpad key (`0–9`, `*`, `#`) or backspace respects the new UI Vibration setting instead of vibrating unconditionally.
  3. **Per-Contact Calling Card Selection in Settings**:
     - Open **Settings → Caller Screen Backdrop (1 Active at a Time)**.
     - Notice the 3 modes: **Video** (global default), **Gallery Photo** (global default), and **Calling Card (Per Contact)**.
     - Tap **Calling Card** (or **Pick Contact & Calling Card**): a searchable **Select Contact for Calling Card** bottom sheet appears showing your contacts, their avatars, phone numbers, and which contacts already have an active Calling Card.
     - Tap any contact row → Android's zero-permission Photo Picker (`PickVisualMedia.ImageOnly`) opens → select an image → the image is saved with persisted URI permission exclusively to that contact, and that contact's active backdrop mode switches to **Calling Card** (turning Video and Photo off for that contact).
     - Contacts that already have a Calling Card show a thumbnail/active badge and an inline **Clear** action inside the contact menu.
- **Visual Identity & Theme**:
  - Follows Dot Dial's Nothing OS aesthetic: high-contrast `surfaceVariant` sheets with hairline borders, active red-dot indicators (`primary`) on contacts with custom Calling Cards, rounded pill actions, `48dp+` interactive targets, and full Light / Dark / Auto Day-Night theme adaptation.
- **Interactive Feedback & Motion**:
  - Ripple feedback on every contact row in the picker sheet, instant status snackbar confirmation (`"Calling Card assigned to <Name>."`), and crisp spring/modal bottom sheet presentation with safe navigation-bar padding.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Centralized Haptic Dispatch via Shared Switch & ViewModel Helper**:
  - *Chosen Approach*: Add a `pulseUiHaptic()` helper on the ViewModel gated on `settings.uiVibrationEnabled`, and wire it into navigation tab taps, shared Settings switch controls (`SettingsSwitchRow` and standalone switches), and dialpad key/backspace handlers.
  - *Why*: Wiring haptics inside shared switch components and central navigation/dialpad handlers guarantees consistent vibration on every ON/OFF toggle across the entire Settings screen without scattering `Vibrator` calls through UI composables.
  - *Alternatives Considered*: Using Compose `LocalHapticFeedback` everywhere, which ignores our Settings ON/OFF preference and can follow system keyboard settings inconsistently across devices.
- **Decision 2 — Strictly Per-Contact Calling Cards (No Global Calling Card Override)**:
  - *Chosen Approach*: Remove global Calling Card assignment from Settings and manage Calling Cards per-contact inside the Settings contact picker sheet (as well as inside the Contacts detail/editor sheets).
  - *Why*: Matches the mental model that a "Calling Card" represents a specific person's caller poster rather than a universal wallpaper. Global fallback backdrops remain available via **Video** and **Gallery Photo**.
  - *Alternatives Considered*: Keeping a hidden global fallback card, which creates confusion when the user expects each contact to have their own card.

---

## 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────────────┐
│                         SETTINGS & NAVIGATION UI                     │
│                                                                      │
│  [Bottom/Rail Tabs] ──┐                                              │
│  [Settings Switches] ─┼─▶ pulseUiHaptic() (if uiVibrationEnabled)   │
│  [Dialpad Keys] ──────┘         │                                    │
│                                 ▼                                    │
│                     VibrationGlyphEngine.pulseKeypadTick()           │
│                                                                      │
│  [Settings: Calling Card Mode]                                       │
│         │ tap                                                        │
│         ▼                                                            │
│  [ContactCallingCardPickerSheet] (search + active card badges)       │
│         │ choose contact                                             │
│         ▼                                                            │
│  [Android Photo Picker (ImageOnly)] ──▶ assignContactCallingCard()   │
└──────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
┌──────────────────────────────────────────────────────────────────────┐
│                        PERSISTENCE & TELECOM                         │
│  • DialerPreferences (DataStore): uiVibrationEnabled (default = true)│
│  • ContactRepository / Room: ContactEntity.callingCardUri + mode     │
│  • CallSessionBridge: Resolves per-contact CALLING_CARD on calls     │
└──────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - Add `uiVibrationEnabled: Boolean = true` to `DialerSettings` and persist via DataStore (`UI_VIBRATION_ENABLED`), including `encodeSettingsJson` / `applySettingsJson` backup compatibility.
  - Reuse existing `ContactEntity.callingCardUri` and `ContactEntity.callerBackdropMode` (`CallerBackdropMode.CALLING_CARD`) so per-contact exclusivity (`VIDEO` / `PHOTO` / `CALLING_CARD`) remains consistent whether edited from Settings or Contacts.
- **Interactive Component & State Mapping**:
  - `DisplayAndAudioSettingsCard` gains the **UI Navigation & Toggle Vibration** switch (`ui_vibration_switch`).
  - `SettingsSwitchRow` accepts/invokes the haptic pulse callback on every toggle state change (`true` or `false`), and standalone switches (such as in Audio/Recording/AI/Vault cards) also trigger the haptic callback.
  - `SettingsScreen` receives the contact list, `onAssignContactCallingCard(ContactEntity, Uri?)`, and a `onUiHapticPulse` callback; tapping **Calling Card** opens the searchable Contact Calling Card sheet, stores the `pendingCallingCardContact`, launches `PickVisualMedia(ImageOnly)`, and persists the picked image to that contact (with persisted URI permissions).
  - Settings backup JSON export/restore preserves `uiVibrationEnabled`, and unit tests verify default `uiVibrationEnabled = true` and per-contact calling card resolution.
