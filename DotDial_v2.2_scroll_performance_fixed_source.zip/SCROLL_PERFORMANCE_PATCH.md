# Dot Dial v2.2 scroll-performance patch

This patch is based on the user's v2.2 Stable Fixed source ZIP (versionCode 7, versionName 2.2), not the older v1.6 GitHub checkout.

Changes:
- Compose BOM: 2024.09.00 → 2025.08.00 (Compose 1.9 generation, which introduces improved Lazy List/Lazy Grid prefetch behavior and scrolling performance).
- Added stable `contentType` metadata to the vibration-pattern LazyRow in ContactsScreen.
- Added stable `contentType` metadata to the contacts LazyColumn in SettingsCallingCardPickerSheet.
- Incremented `versionCode` from 7 to 8 while keeping `versionName` at 2.2.

No changes were made to DotDialBackgroundHost, UI background mode selection, dot-matrix rendering, wallpaper loading, wallpaper dimming, or background settings persistence. The original v2.2 source files and assets are retained.

The connected GitHub repository workflow has been configured to build this exact v2.2 source archive after it is uploaded to the repository root. It first replaces the old checked-out app/ and gradle/ trees with the archive contents, verifies versionCode 8 / versionName 2.2, then builds and uploads the v2.2 release APK artifact.

Build signing note: the CI workflow creates a temporary sideload signing key. This is not the app's original AI Studio upload key and cannot be used for Play Store publishing. Android may require uninstalling an older differently-signed build before installing this APK, which can erase local app data unless backed up.
