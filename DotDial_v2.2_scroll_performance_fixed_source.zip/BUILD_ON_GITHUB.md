# Build Dot Dial v2.2 from a phone

1. Open the private GitHub repository `Ajking420/Dot-Dial`.
2. In the repository root, choose **Add file → Upload files**.
3. Upload `DotDial_v2.2_scroll_performance_fixed_source.zip` (do not extract it first) and commit to `main`.
4. The repository's updated GitHub Actions workflow detects that ZIP, unpacks the v2.2 project over the old v1.6 checkout, and starts the build automatically.
5. When the run succeeds, open **Actions → Build DotDial v2.2 scroll-fixed release APK → Artifacts** and download `Dot-Dial-v2.2-scroll-fixed`.
6. Extract the artifact ZIP and install the APK.

The CI signing key is temporary and differs from the original AI Studio key. Back up any Dot Dial data that is not already backed up before uninstalling an older app if Android reports a signature conflict.
